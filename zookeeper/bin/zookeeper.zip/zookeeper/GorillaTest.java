package zookeeper;

public class GorillaTest {
	public static void main(String[] args) {
		Gorilla newGorilla = new Gorilla();
		newGorilla.throwSomething();
		newGorilla.throwSomething();
		newGorilla.throwSomething();
		newGorilla.eatBananas();
		newGorilla.eatBananas();
		newGorilla.climb();
		}
}
